
package ch01;

public class dorkar
{
   
    public String show_id;
    public String start_time;
    
    public String movie_name;
    public String genre;
    public int length;
     public int hall_no;
    public String movie_id;
    public String date;
    public int price;

    public dorkar(String show_id,String start_time,String movie_name,String genre,int length,int hall_no,String movie_id,String date,int price) {
        this.show_id = show_id ;
        this.start_time = start_time;
        this.movie_name = movie_name;
        this.genre=genre;
        this.length=length;
        this.hall_no=hall_no;
        this.date=date;
        this.price=price;
        this.movie_id=movie_id;
        
    }
}
