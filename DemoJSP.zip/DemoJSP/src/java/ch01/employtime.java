
package ch01;

public class employtime
{
   
    public String user_name;
    public String pass;
    
    public String first_name;
    public String last_name;
    public String job_type;
    

    public employtime(String user_name,String pass,String first_name,String last_name,String job_type) {
        this.user_name = user_name;
        this.pass = pass;
        this.first_name = first_name;
        this.last_name=last_name;
        this.job_type=job_type;
        
        
    }
}
